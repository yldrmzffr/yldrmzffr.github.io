﻿/*
 * Created by SharpDevelop.
 * User: AKML
 * Date: 15.06.2017
 * Time: 19:46
 * 
 * To change this template use Tools | Options | Coding | Edit Standard Headers.
 */
namespace titre
{
	partial class MainForm
	{
		/// <summary>
		/// Designer variable used to keep track of non-visual components.
		/// </summary>
		private System.ComponentModel.IContainer components = null;
		private System.Windows.Forms.Button buton;
		private System.Windows.Forms.Button formb;
		private System.Windows.Forms.Label label1;
		
		/// <summary>
		/// Disposes resources used by the form.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing) {
				if (components != null) {
					components.Dispose();
				}
			}
			base.Dispose(disposing);
		}
		
		/// <summary>
		/// This method is required for Windows Forms designer support.
		/// Do not change the method contents inside the source code editor. The Forms designer might
		/// not be able to load this method if it was changed manually.
		/// </summary>
		private void InitializeComponent()
		{
			this.buton = new System.Windows.Forms.Button();
			this.formb = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// buton
			// 
			this.buton.Location = new System.Drawing.Point(33, 22);
			this.buton.Name = "buton";
			this.buton.Size = new System.Drawing.Size(140, 41);
			this.buton.TabIndex = 0;
			this.buton.Text = "Butonu Titret";
			this.buton.UseVisualStyleBackColor = true;
			this.buton.Click += new System.EventHandler(this.ButonClick);
			// 
			// formb
			// 
			this.formb.Location = new System.Drawing.Point(33, 87);
			this.formb.Name = "formb";
			this.formb.Size = new System.Drawing.Size(140, 41);
			this.formb.TabIndex = 1;
			this.formb.Text = "Formu Titret";
			this.formb.UseVisualStyleBackColor = true;
			this.formb.Click += new System.EventHandler(this.FormbClick);
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(12, 131);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(185, 23);
			this.label1.TabIndex = 2;
			this.label1.Text = "yldrmzffr.com";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// MainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(209, 160);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.formb);
			this.Controls.Add(this.buton);
			this.Name = "MainForm";
			this.Text = "Titre";
			this.ResumeLayout(false);

		}
	}
}
