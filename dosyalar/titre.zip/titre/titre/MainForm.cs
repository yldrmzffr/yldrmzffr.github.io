﻿/*
 * Muzaffer YILDIRIM
 * https://yldrmzffr.com
 * muzaffer@yldrmzffr.com
 * 15.06.2017
 */
using System;
using System.Drawing;
using System.Windows.Forms;

namespace titre
{

	public partial class MainForm : Form
	{
		public MainForm()
		{

			InitializeComponent();
			
		}
		
		void ButonClick(object sender, EventArgs e)
		{
			
			Random r = new Random();
			Point konum =buton.Location;
			for(int i=0;i<50;i++){
				int x = r.Next(-2,2);
				int y = r.Next(-2,2);
				buton.Location = new Point(konum.X + x, konum.Y + y);
				System.Threading.Thread.Sleep(10);
			}
			buton.Location=konum;
	
		}
		void FormbClick(object sender, EventArgs e)
		{
			
			Random rnd = new Random();
			Point konum = Location;
			for(int i=0;i<50;i++){
				int x = rnd.Next(-2,2);
				int y = rnd.Next(-2,2);
				Location = new Point(konum.X + x, konum.Y + y);
				System.Threading.Thread.Sleep(10);
			}
			Location=konum;
			
		}
		
	}
}
